<?php
/* Public navigation bar. Add a link to $links when you add a public page. */
$links = ['index.php' => 'Home', 'about.php' => 'About', 'announcements.php' => 'Announcements', 'events.php' => 'Events',
          'officials.php' => 'Officials', 'services.php' => 'Services', 'contact.php' => 'Contact'];
$parents = ['announcement-details.php' => 'announcements.php', 'event-details.php' => 'events.php']; // detail pages highlight their list page
$here = basename($_SERVER['SCRIPT_NAME']);
$active = $parents[$here] ?? $here;
?>
<header class="site-nav">
  <a class="brand" href="<?= e(url('index.php')) ?>"><?= e(site_name()) ?></a>
  <button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="site-menu">&#9776;</button>
  <nav id="site-menu" aria-label="Main">
    <?php foreach ($links as $file => $label): ?>
      <a href="<?= e(url($file)) ?>"<?= $file === $active ? ' class="active" aria-current="page"' : '' ?>><?= e($label) ?></a>
    <?php endforeach; ?>
    <a class="btn btn-ghost" href="<?= e(url('admin/login.php')) ?>">Admin login</a>
  </nav>
</header>
